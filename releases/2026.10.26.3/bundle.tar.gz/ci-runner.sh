#!/bin/bash
# The CI runner on Pedro's PC (deploy/client/compose.yaml, service ci-runner), on GitHub's runner image.
# It registers with the token the builder puts in /ci/registration-token (tools/ci-register.sh, valid one
# hour), keeps its registration in /state, then runs jobs. A token newer than the registration means
# "register again" (GitHub removed this runner, after 14 days offline): the old one is dropped.
set -u
cd /home/runner
# Named volumes start out owned by root.
sudo chown runner:runner /state /home/runner/.cargo /home/runner/.rustup
if [ -f /state/.runner ] && [ /ci/registration-token -nt /state/.runner ]; then
  echo "a newer registration token: registering again"
  rm -f /state/.runner /state/.credentials /state/.credentials_rsaparams
fi
while [ ! -f /state/.runner ]; do
  token=$(cat /ci/registration-token 2>/dev/null || true)
  if [ -z "$token" ]; then
    echo "waiting for a registration token in /ci/registration-token (tools/ci-register.sh)"
  elif ./config.sh --unattended --replace --url "$REPO_URL" --token "$token" \
      --name "${RUNNER_NAME:-pedro-pc}" --labels wow-coach --work /state/_work; then
    cp .runner .credentials .credentials_rsaparams /state/
    break
  else
    echo "registration failed (the token may have expired): waiting for a new one"
  fi
  sleep 30
done
cp /state/.runner /state/.credentials /state/.credentials_rsaparams .
exec ./run.sh
