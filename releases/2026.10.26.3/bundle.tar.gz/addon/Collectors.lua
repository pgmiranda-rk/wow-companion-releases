-- ForeverCoach collectors: each reads one part of the game when the game says it
-- changed, and sends what it can see. Every read goes through ns.clean / ns.guard,
-- so a secret value is reported as secret and never used.

local ADDON, ns = ...
local guard, clean, send, list = ns.guard, ns.clean, ns.send, ns.list

-- Calls fn(...) and returns its results cleaned; an error becomes { error = text }. Counted, not `#`: a
-- nil in the middle (EJ_GetEncounterInfoByIndex's link) must not drop the values after it.
local function pack(...) return { n = select("#", ...), ... } end
local function read(fn, ...)
	if type(fn) ~= "function" then return nil end
	local r = pack(pcall(fn, ...))
	if not r[1] then return { error = tostring(r[2]) } end
	for i = 2, r.n do r[i] = clean(r[i]) end
	return unpack(r, 2, r.n)
end

-- A Blizzard API function by namespace and name, or nil if this client lacks it.
local function api(space, name)
	local t = _G[space]
	return type(t) == "table" and t[name] or nil
end

local function num(v) return type(v) == "number" and v or nil end

-- A table result as a list to iterate, or an empty one.
local function each(v) return type(v) == "table" and v or {} end

-- A position object's x and y, if readable.
local function xy(pos)
	if type(pos) ~= "table" then return nil end
	if pos.GetXY then
		local ok, x, y = pcall(pos.GetXY, pos)
		if ok then return guard(x), guard(y) end
		return nil
	end
	return pos.x, pos.y
end

-- The creature or vehicle ID inside a unit GUID ("Creature-0-…-<npcID>-…"), if readable.
local function npcID(guid)
	if type(guid) ~= "string" then return nil end
	local kind, id = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
	if kind == "Creature" or kind == "Vehicle" or kind == "Pet" then return tonumber(id) end
	return nil
end
ns.npcID = npcID

-- Item stats and level, for comparing a quest reward or a drop against what is worn.
local function itemDetail(link)
	if type(link) ~= "string" then return nil end
	-- What it is and who can wear it, for comparing gear: slot, armour or weapon class, required level.
	local name, _, quality, _, minLevel, _, subType, _, equipLoc, _, _, classID, subclassID, bindType =
		read(api("C_Item", "GetItemInfo"), link)
	-- Classic-era stats that are only "Equip:" lines (spell damage, hit, crit, attack power…):
	-- GetItemStats does not return them, so the tooltip's lines go to the coach to read.
	local equip = list()
	local tip = read(api("C_TooltipInfo", "GetHyperlink"), link)
	local prefix = type(ITEM_SPELL_TRIGGER_ONEQUIP) == "string" and ITEM_SPELL_TRIGGER_ONEQUIP or "Equip:"
	for _, line in ipairs(type(tip) == "table" and each(tip.lines) or {}) do
		local text = type(line) == "table" and line.leftText
		if type(text) == "string" and text:sub(1, #prefix) == prefix then -- read() made secrets non-strings
			equip[#equip + 1] = text
		end
	end
	return {
		stats = read(api("C_Item", "GetItemStats"), link), itemLevel = read(api("C_Item", "GetDetailedItemLevelInfo"), link),
		name = name, quality = quality, minLevel = minLevel, subType = subType,
		equipLoc = equipLoc ~= "" and equipLoc or nil, classID = classID, subclassID = subclassID, bindType = bindType,
		equip = equip,
	}
end
ns.itemDetail = itemDetail

-- What a unit token shows: target, a nameplate, the NPC you talk to.
local function describe(unit)
	if read(UnitExists, unit) ~= true then return { exists = false } end
	local health, healthMax = read(UnitHealth, unit), read(UnitHealthMax, unit)
	local guid = read(UnitGUID, unit)
	return {
		exists = true, name = read(UnitName, unit), guid = guid, npcID = npcID(guid),
		level = read(UnitLevel, unit), classification = read(UnitClassification, unit),
		reaction = read(UnitReaction, unit, "player"), creatureType = read(UnitCreatureType, unit),
		dead = read(UnitIsDead, unit), questBoss = read(UnitIsQuestBoss, unit), boss = read(UnitIsBossMob, unit), tapDenied = read(UnitIsTapDenied, unit),
		-- Its power: MANA is a caster or healer, the rest fight in melee (readable inside, where its name is not).
		powerType = select(2, read(UnitPowerType, unit)),
		health = health, healthMax = healthMax,
		healthPct = (num(health) and num(healthMax) and healthMax > 0) and math.floor(health * 1000 / healthMax) / 10 or nil,
	}
end
ns.describe = describe

local collect = {}

function collect.player()
	local name, realm = read(UnitName, "player")
	local _, class = read(UnitClass, "player")
	local _, race = read(UnitRace, "player")
	return {
		name = name, realm = realm or read(GetNormalizedRealmName), class = class, race = race,
		level = read(UnitLevel, "player"), xp = read(UnitXP, "player"), xpMax = read(UnitXPMax, "player"),
		rested = read(GetXPExhaustion), resting = read(IsResting), hearth = read(GetBindLocation),
		money = read(GetMoney), inCombat = read(UnitAffectingCombat, "player"), dead = read(UnitIsDead, "player"),
		hardcore = read(api("C_GameRules", "IsHardcoreActive")), selfFound = read(api("C_PlayerInfo", "IsSelfFoundActive")),
		interface = select(4, read(GetBuildInfo)), project = WOW_PROJECT_ID,
	}
end

-- Health and power in 10% steps: enough to say "drink" or "low health", and it only
-- changes a few times a fight.
function collect.vitals()
	local function pct(cur, max)
		if num(cur) and num(max) and max > 0 then return math.floor(cur * 10 / max + 0.5) * 10 end
		return cur
	end
	return {
		healthPct = pct(read(UnitHealth, "player"), read(UnitHealthMax, "player")),
		powerPct = pct(read(UnitPower, "player"), read(UnitPowerMax, "player")),
	}
end

function collect.location()
	local mapID = read(api("C_Map", "GetBestMapForUnit"), "player")
	local x, y
	if num(mapID) then x, y = xy(read(api("C_Map", "GetPlayerMapPosition"), mapID, "player")) end
	local instanceName, instanceType, difficultyID = read(GetInstanceInfo)
	-- The map's size in yards, so the coach can say distances as a run ("a short run"), not map percent.
	local width, height
	if num(mapID) then width, height = read(api("C_Map", "GetMapWorldSize"), mapID) end
	return {
		zone = read(GetRealZoneText), subzone = read(GetSubZoneText), mapID = mapID, x = x, y = y,
		yards = num(width) and num(height) and { w = width, h = height } or nil,
		facing = read(GetPlayerFacing), instance = read(IsInInstance) == true and { name = instanceName, type = instanceType, difficultyID = difficultyID } or nil,
	}
end

-- The last target seen with a readable identity: combat may hide it a moment later. It
-- only counts for a pull shortly after it was seen, so a fight is never put on a mob
-- targeted minutes earlier.
local lastKnownTarget, lastKnownAt
local RECENT = 15

local function recentTarget()
	if lastKnownAt and ns.now() - lastKnownAt <= RECENT then return lastKnownTarget end
	return nil
end

-- Seconds since a readable target was last seen, for the coach to judge (nil if never).
local function targetAge()
	return lastKnownAt and math.floor((ns.now() - lastKnownAt) * 10) / 10 or nil
end

function collect.target()
	local d = describe("target")
	if d.exists and type(d.name) == "string" then lastKnownTarget, lastKnownAt = d, ns.now() end
	return d
end

function collect.restrict()
	local names = { [0] = "combat", "encounter", "challengeMode", "pvpMatch", "map", "chat" }
	local out = {}
	for kind = 0, 5 do out[names[kind]] = ns.restricted(kind) end
	return out
end

-- The game's own quest map for the zone he is in: quest offers (as the world map shows them) and
-- where his quests are. Edition-agnostic: the plan is built from this first, the quest database adds.
local questLinesFor
function collect.questmap()
	local mapID = read(api("C_Map", "GetBestMapForUnit"), "player")
	if not num(mapID) then return { mapID = nil } end
	-- Ask for a map's quest lines once (the answer comes as QUESTLINE_UPDATE, which reports this
	-- again): asking on every update would ask forever.
	local request = api("C_QuestLine", "RequestQuestLinesForMap")
	if request and questLinesFor ~= mapID then
		questLinesFor = mapID
		pcall(request, mapID)
	end
	-- An offer starting on another map comes projected onto this one (Orgrimmar's events on the
	-- Barrens): Blizzard's world map leaves out those not starting here or on a map inside this one
	-- (QuestOfferDataProvider), and `here` says the same.
	local mapInfo = api("C_Map", "GetMapInfo")
	local function inside(m)
		for _ = 1, 10 do
			if m == mapID then return true end
			local info = mapInfo and read(mapInfo, m)
			m = type(info) == "table" and num(info.parentMapID) and info.parentMapID or nil
			if not m or m == 0 then return false end
		end
		return false
	end
	local offers = list()
	for _, q in ipairs(each(read(api("C_QuestLine", "GetAvailableQuestLines"), mapID))) do
		if num(q.questID) then
			local start = num(q.startMapID) and q.startMapID or nil
			offers[#offers + 1] = {
				id = q.questID, name = q.questName, x = q.x, y = q.y, line = q.questLineName,
				trivial = q.isHidden, campaign = q.isCampaign, important = q.isImportant,
				startMap = start, here = start == nil or inside(start),
			}
		end
	end
	local onMap = list()
	for _, q in ipairs(each(read(api("C_QuestLog", "GetQuestsOnMap"), mapID))) do
		if num(q.questID) then onMap[#onMap + 1] = { id = q.questID, x = q.x, y = q.y, start = q.isQuestStart } end
	end
	return { mapID = mapID, offers = offers, onMap = onMap }
end

-- A sign of life every minute: the addon sends only what changes, so without it a player standing
-- still and a game that stopped look the same to the coach.
function collect.heartbeat()
	return { at = ns.now() }
end

function collect.features()
	local meter, why = read(api("C_DamageMeter", "IsDamageMeterAvailable"))
	return {
		encounterWarnings = read(api("C_EncounterWarnings", "IsFeatureAvailable")),
		encounterTimeline = read(api("C_EncounterTimeline", "IsFeatureAvailable")),
		damageMeter = meter, damageMeterWhyNot = why,
	}
end

function collect.quests()
	local quests = list()
	for i = 1, (num(read(api("C_QuestLog", "GetNumQuestLogEntries"))) or 0) do
		local info = read(api("C_QuestLog", "GetInfo"), i)
		if type(info) == "table" and info.isHeader ~= true and num(info.questID) then
			local objectives = list()
			for _, o in ipairs(each(read(api("C_QuestLog", "GetQuestObjectives"), info.questID))) do
				objectives[#objectives + 1] = { text = o.text, type = o.type, have = o.numFulfilled, need = o.numRequired, done = o.finished }
			end
			local wpMap, wpX, wpY = read(api("C_QuestLog", "GetNextWaypoint"), info.questID)
			quests[#quests + 1] = {
				id = info.questID, title = info.title, level = info.level, frequency = info.frequency,
				complete = read(api("C_QuestLog", "IsComplete"), info.questID), objectives = objectives,
				waypoint = num(wpMap) and { mapID = wpMap, x = wpX, y = wpY } or nil,
			}
		end
	end
	return { count = #quests, quests = quests }
end

function collect.completedQuests()
	local ids = list()
	for _, id in ipairs(each(read(api("C_QuestLog", "GetAllCompletedQuestIDs")))) do
		if num(id) then ids[#ids + 1] = id end
	end
	return { count = #ids, ids = ids }
end

-- The quest frame's items of one type ("choice" or "reward").
local function questItems(kind, count)
	local items = list()
	for i = 1, (num(count) or 0) do
		local name, _, amount, quality, usable = read(GetQuestItemInfo, kind, i)
		local link = read(GetQuestItemLink, kind, i)
		items[#items + 1] = { name = name, count = amount, quality = quality, usable = usable, link = link, detail = itemDetail(link) }
	end
	return items
end

local function questFrame(stage)
	return function()
		return {
			stage = stage, questID = read(GetQuestID), title = read(GetTitleText), npc = read(UnitName, "npc"),
			choices = questItems("choice", read(GetNumQuestChoices)),
			rewards = questItems("reward", read(GetNumQuestRewards)),
			xp = read(GetRewardXP), money = read(GetRewardMoney),
		}
	end
end
collect.questoffer = questFrame("offer")
collect.questprogress = questFrame("progress")
collect.questcomplete = questFrame("complete")

function collect.gossip()
	local options, available, active = list(), list(), list()
	for _, o in ipairs(each(read(api("C_GossipInfo", "GetOptions")))) do
		options[#options + 1] = { id = o.gossipOptionID, name = o.name }
	end
	for _, q in ipairs(each(read(api("C_GossipInfo", "GetAvailableQuests")))) do
		available[#available + 1] = { id = q.questID, title = q.title, level = q.questLevel }
	end
	for _, q in ipairs(each(read(api("C_GossipInfo", "GetActiveQuests")))) do
		active[#active + 1] = { id = q.questID, title = q.title, complete = q.isComplete }
	end
	return { npc = describe("npc"), options = options, available = available, active = active }
end

function collect.merchant()
	local cost, canRepair = read(GetRepairAllCost)
	return {
		npc = describe("npc"), items = read(GetMerchantNumItems),
		canRepair = read(CanMerchantRepair), repairCost = cost, repairPossible = canRepair,
	}
end

function collect.trainer()
	local services = list()
	for i = 1, (num(read(GetNumTrainerServices)) or 0) do
		-- As Blizzard_TrainerUI reads it: name, type, texture, required level, rank, category.
		local name, serviceType, _, reqLevel, rank, category = read(GetTrainerServiceInfo, i)
		services[#services + 1] = {
			name = name, type = serviceType, requiredLevel = reqLevel, rank = rank, category = category,
			cost = read(GetTrainerServiceCost, i),
		}
	end
	return { npc = describe("npc"), services = services }
end

function collect.taxi()
	local nodes = list()
	-- The flight map's own map, as Blizzard_FlightMap uses it; the zone map as a fallback.
	local mapID = read(GetTaxiMapID)
	if not num(mapID) then mapID = read(api("C_Map", "GetBestMapForUnit"), "player") end
	for _, n in ipairs(each(read(api("C_TaxiMap", "GetAllTaxiNodes"), mapID))) do
		local x, y = xy(n.position)
		nodes[#nodes + 1] = { id = n.nodeID, name = n.name, state = n.state, x = x, y = y }
	end
	return { mapID = mapID, nodes = nodes }
end

function collect.loot()
	local items = list()
	for i = 1, (num(read(GetNumLootItems)) or 0) do
		local _, name, quantity, currencyID, quality = read(GetLootSlotInfo, i)
		local link = read(GetLootSlotLink, i)
		items[#items + 1] = { name = name, count = quantity, quality = quality, currencyID = currencyID, link = link, detail = itemDetail(link) }
	end
	return { source = describe("target"), items = items }
end

function collect.equipment()
	local slots = list()
	for slot = 1, 19 do
		local link = read(GetInventoryItemLink, "player", slot)
		if link then
			local cur, max = read(GetInventoryItemDurability, slot)
			slots[#slots + 1] = { slot = slot, link = link, detail = itemDetail(link), durability = cur, durabilityMax = max }
		end
	end
	return { slots = slots }
end

function collect.bags()
	local counts, free, size, gear = {}, 0, 0, list()
	for bag = 0, 5 do
		local slots = num(read(api("C_Container", "GetContainerNumSlots"), bag)) or 0
		size = size + slots
		free = free + (num(read(api("C_Container", "GetContainerNumFreeSlots"), bag)) or 0)
		for slot = 1, slots do
			local info = read(api("C_Container", "GetContainerItemInfo"), bag, slot)
			if type(info) == "table" and num(info.itemID) then
				counts[info.itemID] = (counts[info.itemID] or 0) + (num(info.stackCount) or 1)
				-- Gear he carries, with its stats: an upgrade in the bags is only found if it is seen.
				if type(info.hyperlink) == "string" and read(api("C_Item", "IsEquippableItem"), info.itemID) == true then
					gear[#gear + 1] = { bag = bag, slot = slot, id = info.itemID, link = info.hyperlink, detail = itemDetail(info.hyperlink) }
				end
			end
		end
	end
	local items = list()
	for id, count in pairs(counts) do items[#items + 1] = { id = id, count = count } end
	table.sort(items, function(a, b) return a.id < b.id end)
	return { size = size, free = free, items = items, gear = gear }
end

function collect.profession()
	return { base = read(api("C_TradeSkillUI", "GetBaseProfessionInfo")) }
end

function collect.spec()
	local index = read(api("C_SpecializationInfo", "GetSpecialization"))
	if not num(index) then return { index = index } end
	local id, name, _, _, role, primaryStat = read(api("C_SpecializationInfo", "GetSpecializationInfo"), index)
	return { index = index, id = id, name = name, role = role, primaryStat = primaryStat }
end

-- A talent's name and (when asked) what it does, from its entry in the tree. A hero-tree choice
-- has no definition: its name is the hero tree's.
local function talentEntry(configID, entryID, withText)
	local entry = num(entryID) and read(api("C_Traits", "GetEntryInfo"), configID, entryID)
	if type(entry) == "table" and num(entry.subTreeID) and not num(entry.definitionID) then
		local sub = read(api("C_Traits", "GetSubTreeInfo"), configID, entry.subTreeID)
		sub = type(sub) == "table" and sub or {}
		return { entry = entryID, name = sub.name, text = withText and sub.description or nil, heroTree = true }
	end
	local def = type(entry) == "table" and num(entry.definitionID) and read(api("C_Traits", "GetDefinitionInfo"), entry.definitionID)
	if type(def) ~= "table" then return { entry = entryID } end
	local spell = num(def.spellID)
	local name = def.overrideName
	if type(name) ~= "string" or name == "" then name = spell and read(api("C_Spell", "GetSpellName"), spell) end
	local text
	if withText then
		text = def.overrideDescription
		if type(text) ~= "string" or text == "" then text = spell and read(api("C_Spell", "GetSpellDescription"), spell) end
		if type(text) == "string" and #text > 300 then text = text:sub(1, 300) .. "…" end
	end
	return { entry = entryID, name = name, spellID = spell, text = text }
end

local talentTree -- the talent tree's ID, once read: other trees' events are not about it

-- The talent tree: points to spend, what he took, and what he can take next (with what each does
-- when he can take it now). Only his spec's nodes and his hero tree's (the tree holds every spec's,
-- and each hero tree keeps its own points). "Now" is as the game's talent frame decides it: the node
-- can take a rank and he has the points it costs.
function collect.talents()
	local configID = read(api("C_ClassTalents", "GetActiveConfigID"))
	if not num(configID) then return { configID = configID } end
	local config = read(api("C_Traits", "GetConfigInfo"), configID)
	local treeID = type(config) == "table" and type(config.treeIDs) == "table" and config.treeIDs[1]
	if not num(treeID) then return { configID = configID } end
	talentTree = treeID
	local have = {}
	local currencies = each(read(api("C_Traits", "GetTreeCurrencyInfo"), configID, treeID, false))
	for _, c in ipairs(currencies) do
		if type(c) == "table" and num(c.traitCurrencyID) then have[c.traitCurrencyID] = num(c.quantity) or 0 end
	end
	local function affordable(nodeID)
		local costs = read(api("C_Traits", "GetNodeCost"), configID, nodeID)
		if type(costs) ~= "table" then return false end
		for _, cost in ipairs(costs) do
			if type(cost) ~= "table" or not num(cost.amount) or (have[cost.ID] or 0) < cost.amount then return false end
		end
		return true
	end
	local picked, nextUp, otherHero = list(), list(), {}
	for _, nodeID in ipairs(each(read(api("C_Traits", "GetTreeNodes"), treeID))) do
		local n = read(api("C_Traits", "GetNodeInfo"), configID, nodeID)
		local rank, max = type(n) == "table" and num(n.currentRank), type(n) == "table" and num(n.maxRanks)
		local sub = rank and num(n.subTreeID)
		if sub and n.subTreeActive ~= true then otherHero[sub] = true end
		if rank and max and n.isVisible == true and (not sub or n.subTreeActive == true) then
			local hero = sub and true or nil
			local now = n.canPurchaseRank == true and affordable(nodeID)
			local active = type(n.activeEntry) == "table" and n.activeEntry.entryID or each(n.entryIDs)[1]
			if rank > 0 then
				picked[#picked + 1] = { name = talentEntry(configID, active).name, rank = rank, max = max, hero = hero }
				if now and rank < max then
					nextUp[#nextUp + 1] = { node = nodeID, rank = rank, max = max, now = true, hero = hero, options = { talentEntry(configID, active, true) } }
				end
			elseif now or n.isAvailable == true and n.meetsEdgeRequirements == true then
				local options = list()
				for _, entryID in ipairs(each(n.entryIDs)) do options[#options + 1] = talentEntry(configID, entryID, now) end
				nextUp[#nextUp + 1] = { node = nodeID, max = max, now = now, choice = n.type == 2 or n.type == 3 or nil, hero = hero, options = options }
			end
		end
	end
	-- The hero trees he did not choose keep points he cannot spend: not his to spend.
	local skip = {}
	for sub in pairs(otherHero) do
		local info = read(api("C_Traits", "GetSubTreeInfo"), configID, sub)
		if type(info) == "table" and num(info.traitCurrencyID) then skip[info.traitCurrencyID] = true end
	end
	local points, unspent = list(), 0
	for _, c in ipairs(currencies) do
		if type(c) == "table" and not skip[c.traitCurrencyID] then
			points[#points + 1] = { currency = c.traitCurrencyID, unspent = c.quantity, spent = c.spent, max = c.maxQuantity }
			unspent = unspent + (num(c.quantity) or 0)
		end
	end
	return { configID = configID, treeID = treeID, unspent = unspent, points = points, picked = picked, next = nextUp }
end

-- The Encounter Journal is shared with his own journal window: selecting an instance, a difficulty or a
-- loot filter changes what his window shows. Borrow it, and put back what he had; never while his window
-- is open.
local function withJournal(fn)
	local frame = rawget(_G, "EncounterJournal")
	if type(frame) == "table" and frame.IsShown and read(frame.IsShown, frame) == true then return nil end
	local instance = type(frame) == "table" and num(frame.instanceID)
	local filterClass, filterSpec = read(EJ_GetLootFilter)
	local difficulty = read(EJ_GetDifficulty)
	local ok, result = pcall(fn)
	if num(filterClass) then read(EJ_SetLootFilter, filterClass, num(filterSpec) or 0) end
	if num(difficulty) then read(EJ_SetDifficulty, difficulty) end
	if instance then read(EJ_SelectInstance, instance) end
	return ok and result or nil
end

-- Inside an instance: which one, its floors, its bosses (the Encounter Journal, where the client has one)
-- and progress (the scenario's criteria, where it has them). His position is hidden inside (retail probe,
-- 2026-10-19), and so is which mob is which.
function collect.dungeon()
	if read(IsInInstance) ~= true then return { inside = false } end
	local name, itype, difficultyID, _, _, _, _, instanceID = read(GetInstanceInfo)
	local mapID = read(api("C_Map", "GetBestMapForUnit"), "player")
	local floors = list()
	local group = num(mapID) and read(api("C_Map", "GetMapGroupID"), mapID)
	if num(group) then
		for _, f in ipairs(each(read(api("C_Map", "GetMapGroupMembersInfo"), group))) do
			if type(f) == "table" then floors[#floors + 1] = { mapID = f.mapID, name = f.name } end
		end
	end
	local bosses = list()
	local journal = num(mapID) and read(EJ_GetInstanceForMap, mapID)
	if num(journal) and journal > 0 then
		-- By index with the instance given: no selection needed, so his journal is untouched.
		for i = 1, 20 do
			local bossName, _, _, _, _, _, encounterID = read(EJ_GetEncounterInfoByIndex, i, journal)
			if type(bossName) ~= "string" then break end
			bosses[#bosses + 1] = { name = bossName, id = encounterID }
		end
	end
	local progress = list()
	for i = 1, 12 do
		local c = read(api("C_ScenarioInfo", "GetCriteriaInfo"), i)
		if type(c) ~= "table" then break end
		progress[#progress + 1] = { text = c.description, done = c.completed, id = c.assetID }
	end
	return {
		inside = true, name = name, type = itype, difficultyID = difficultyID, instanceID = instanceID, mapID = mapID,
		floors = floors, journal = num(journal) and journal > 0 and journal or nil, bosses = bosses, progress = progress,
	}
end

-- The Encounter Journal's guide to this instance's bosses, where the client has one (retail; Forever is
-- expected not to): each boss's overview, the section for each role (by the journal's own role flag, as
-- its window reads it: 0 tank, 1 damage, 2 healer), and loot for his class and spec.
local ROLE_FLAG = { [0] = "TANK", [1] = "DAMAGER", [2] = "HEALER" }
local function readGuide(journal)
	read(EJ_SelectInstance, journal)
	local _, _, difficultyID = read(GetInstanceInfo)
	if num(difficultyID) then read(EJ_SetDifficulty, difficultyID) end
	local _, _, classID = read(UnitClass, "player")
	local spec = read(api("C_SpecializationInfo", "GetSpecialization"))
	local specID = num(spec) and read(api("C_SpecializationInfo", "GetSpecializationInfo"), spec)
	read(EJ_SetLootFilter, num(classID) or 0, num(specID) or 0)
	local section, flags = api("C_EncounterJournal", "GetSectionInfo"), api("C_EncounterJournal", "GetSectionIconFlags")
	local bosses = list()
	for i = 1, 20 do
		local bossName, _, journalEncounterID, rootSection, _, _, encounterID = read(EJ_GetEncounterInfoByIndex, i, journal)
		if type(bossName) ~= "string" then break end
		local boss = { name = bossName, id = encounterID, roles = {}, loot = list() }
		local root = num(rootSection) and read(section, rootSection)
		if type(root) == "table" and root.headerType == 3 then -- the overview, with the role sections under it
			boss.overview = root.description
			local id, guard = root.firstChildSectionID, 0
			while num(id) and guard < 10 do
				guard = guard + 1
				local s = read(section, id)
				if type(s) ~= "table" then break end
				local role = ROLE_FLAG[each(read(flags, id))[1]]
				if role and not s.filteredByDifficulty then boss.roles[role] = s.description end
				id = s.siblingSectionID
			end
		end
		read(EJ_SelectEncounter, journalEncounterID)
		for l = 1, num(read(EJ_GetNumLoot)) or 0 do
			local item = read(api("C_EncounterJournal", "GetLootInfoByIndex"), l)
			if type(item) == "table" and type(item.name) == "string" then boss.loot[#boss.loot + 1] = { name = item.name, slot = item.slot } end
		end
		bosses[#bosses + 1] = boss
	end
	return { journal = journal, bosses = bosses }
end

function collect.bossguide()
	local mapID = read(api("C_Map", "GetBestMapForUnit"), "player")
	local journal = num(mapID) and read(EJ_GetInstanceForMap, mapID)
	if not (num(journal) and journal > 0) then return { journal = false } end
	return withJournal(function() return readGuide(journal) end) or { journal = journal, busy = true }
end

-- Rares, treasures and events the game marks on the minimap, with where they are.
function collect.vignettes()
	local found = list()
	local mapID = read(api("C_Map", "GetBestMapForUnit"), "player")
	for _, guid in ipairs(each(read(api("C_VignetteInfo", "GetVignettes")))) do
		local info = read(api("C_VignetteInfo", "GetVignetteInfo"), guid)
		if type(info) == "table" then
			local x, y
			if num(mapID) then x, y = xy(read(api("C_VignetteInfo", "GetVignettePosition"), guid, mapID)) end
			found[#found + 1] = {
				name = info.name, id = info.vignetteID, objectGUID = info.objectGUID, npcID = npcID(info.objectGUID),
				atlas = info.atlasName, dead = info.isDead, onMinimap = info.onMinimap, unique = info.isUnique,
				rewardQuestID = info.rewardQuestID, mapID = mapID, x = x, y = y,
			}
		end
	end
	return { count = #found, vignettes = found }
end

function collect.targetAuras()
	local harmful, helpful = list(), list()
	for i = 1, 20 do
		local a = read(api("C_UnitAuras", "GetAuraDataByIndex"), "target", i, "HARMFUL")
		if a == nil then break end
		harmful[#harmful + 1] = type(a) == "table" and { name = a.name, spellId = a.spellId, stacks = a.applications, expires = a.expirationTime, source = a.sourceUnit } or a
	end
	for i = 1, 20 do
		local a = read(api("C_UnitAuras", "GetAuraDataByIndex"), "target", i, "HELPFUL")
		if a == nil then break end
		helpful[#helpful + 1] = type(a) == "table" and { name = a.name, spellId = a.spellId, stacks = a.applications, expires = a.expirationTime } or a
	end
	return { harmful = harmful, helpful = helpful }
end

function collect.targetCast()
	local name, text, _, startMs, endMs, _, _, _, spellID = read(UnitCastingInfo, "target")
	return { name = name, text = text, startMs = startMs, endMs = endMs, spellID = spellID }
end

-- Threat in coarse steps: who is tanking and roughly how close you are to pulling aggro.
function collect.threat()
	local tanking, status, scaled = read(UnitDetailedThreatSituation, "player", "target")
	return { tanking = tanking, status = status, scaledPct = num(scaled) and math.floor(scaled / 10) * 10 or scaled }
end

-- His group: each member's name, class, level, role, whether he leads; and what inspect has read of them
-- (item level, spec), one member at a time, out of combat only.
local inspected, tried, inspecting = {}, {}, nil
-- The buffs a group gives each other (and their group versions): what tactics says nobody wears.
local GROUP_BUFFS = {}
for _, name in ipairs({ "Power Word: Fortitude", "Prayer of Fortitude", "Mark of the Wild", "Gift of the Wild",
	"Arcane Intellect", "Arcane Brilliance", "Blessing of Might", "Greater Blessing of Might", "Blessing of Wisdom",
	"Greater Blessing of Wisdom", "Shadow Protection", "Prayer of Shadow Protection" }) do GROUP_BUFFS[name] = true end
-- Others' auras are readable only out of combat, an encounter, a challenge and PvP (restrictions 0-3); the
-- add-on may have loaded mid-fight, so the game is asked too.
local function aurasReadable()
	if ns.inCombat or read(UnitAffectingCombat, "player") == true then return false end
	for kind = 0, 3 do
		if ns.restricted(kind) then return false end
	end
	return true
end
local function groupUnits()
	local n = num(read(GetNumGroupMembers)) or 0
	local units = {}
	if read(IsInRaid) == true then
		for i = 1, n do units[#units + 1] = "raid" .. i end
	else
		units[1] = "player"
		for i = 1, math.max(n - 1, 0) do units[#units + 1] = "party" .. i end
	end
	return units, n
end
function collect.group()
	local units, n = groupUnits()
	local members = list()
	for _, unit in ipairs(n > 0 and units or {}) do
		if read(UnitExists, unit) == true then
			local _, class = read(UnitClass, unit)
			local guid = read(UnitGUID, unit)
			local m = {
				unit = unit, name = read(UnitName, unit), class = class, level = read(UnitLevel, unit),
				role = read(UnitGroupRolesAssigned, unit), leader = read(UnitIsGroupLeader, unit),
				me = read(UnitIsUnit, unit, "player"), online = read(UnitIsConnected, unit),
			}
			local seen = type(guid) == "string" and inspected[guid]
			if seen then m.itemLevel, m.spec = seen.itemLevel, seen.spec end
			-- His usual group buffs, between pulls only: which of them nobody has. Auras are secret in combat,
			-- an encounter, a challenge or PvP; then, or when a read fails or comes back secret, they are
			-- unknown, never "none". Only the usual ones, sorted: a frame that changes only when they do.
			if aurasReadable() then
				local buffs = list()
				for i = 1, 40 do
					local aura = read(api("C_UnitAuras", "GetAuraDataByIndex"), unit, i, "HELPFUL")
					if aura == nil then break end
					if type(aura) ~= "table" or aura == ns.SECRET or aura.error
						or (aura.name ~= nil and type(aura.name) ~= "string") then
						buffs = nil
						break
					end
					if GROUP_BUFFS[aura.name] then buffs[#buffs + 1] = aura.name end
				end
				if buffs then table.sort(buffs) end
				m.buffs = buffs
			end
			members[#members + 1] = m
		end
	end
	return { size = n, raid = read(IsInRaid) == true, members = members }
end
ns.collect = collect

-- How quickly each kind must reach the coach. Urgent ones force a write within 0.25 s; those
-- that make a moment (SOON) within 1 s; the rest wait for the next write (at most 30 s). Every
-- kind sent through report() is skipped when nothing changed.
local SOON = { quests = true, questmap = true, bags = true, talents = true }
local LAZY = {
	player = true, vitals = true, location = true, restrict = true, quests = true, completedQuests = true,
	equipment = true, bags = true, spec = true, talents = true, threat = true, features = true, targetAuras = true,
	questmap = true, heartbeat = true, bossguide = true, group = true,
}

-- Sends collect[kind]() now, or (when it ran within `gap` seconds) once more after the gap.
-- `within`: at most that many seconds whatever the kind (ns.SOON when this change makes a moment: a level
-- gained, a new area).
local last, pending = {}, {}
local function report(kind, gap, within)
	gap = gap or 0
	local wait = (last[kind] or -math.huge) + gap - GetTime()
	if wait > 0 then
		if not pending[kind] then
			pending[kind] = true
			C_Timer.After(wait, function() pending[kind] = false; report(kind, 0, within) end)
		end
		return
	end
	last[kind] = GetTime()
	local ok, payload = pcall(collect[kind])
	if not ok then payload = { error = tostring(payload) } end
	send(kind, payload, { lazy = LAZY[kind], within = within or (SOON[kind] and ns.SOON) or nil, dedupe = true })
end
ns.report = report

-- Entering the world, the game may not have loaded his gear yet: every slot reads empty (live,
-- 2026-10-20: "it keeps saying that i dont have boots or gloves equipped"; entering a dungeon too). Read
-- it again every 2 s until it is there, for 22 s at most; gear loaded later still comes with
-- UNIT_INVENTORY_CHANGED.
local function settleEquipment(tries)
	C_Timer.After(2, function()
		local ok, payload = pcall(collect.equipment)
		if ok and type(payload) == "table" and #payload.slots == 0 and tries < 10 then
			settleEquipment(tries + 1)
		else
			report("equipment", 0, ns.SOON) -- a correction: soon, not with the next lazy write
		end
	end)
end
ns.settleEquipment = settleEquipment

local SNAPSHOT = {
	"player", "vitals", "spec", "talents", "dungeon", "bossguide", "location", "target", "restrict", "features", "quests", "completedQuests",
	"equipment", "bags", "vignettes", "questmap", "group",
}
function ns.snapshot()
	for _, kind in ipairs(SNAPSHOT) do report(kind) end
end

-- The fight: start, end, the player's casts in between, and Blizzard's damage meter for
-- it once combat restrictions have lifted (the meter is secret during combat).
local fight = { casts = list(), controlled = list() }
-- Casts out of combat, kept for a few seconds: the opener of a pull finishes before combat
-- starts, so it is added to the fight from here (with a negative time).
local precasts = {}
local PRECAST = 5
local METER = {
	damageDone = 0, healingDone = 2, absorbs = 4, interrupts = 5, dispels = 6, damageTaken = 7, avoidableDamageTaken = 8, deaths = 9,
}
local MAX_CASTS = 400
local MAX_CONTROLLED = 30

-- The mob a hit came from: the meter's creatureName is empty inside instances, but the spell's details
-- name the unit behind it (measured in Uldaman, 2026-10-21).
local function hitFrom(sp)
	local d = type(sp.combatSpellDetails) == "table" and sp.combatSpellDetails or nil
	local mob = d and type(d.unitName) == "string" and d.unitName ~= "" and d.unitName or nil
	if type(sp.creatureName) == "string" and sp.creatureName ~= "" then return sp.creatureName end
	return mob
end

-- A spell's cast time in seconds (0: instant), from the spell's own data: a cast that lands pull after pull
-- with nobody interrupting it is a kick missed. Kept per spell.
local castTimes = {}
local function castTime(id)
	if not num(id) then return nil end
	if castTimes[id] == nil then
		local info = read(api("C_Spell", "GetSpellInfo"), id)
		castTimes[id] = type(info) == "table" and num(info.castTime) and info.castTime / 1000 or false
	end
	return castTimes[id] or nil
end

-- Each pull is read as its own session: the meter's current one can still be the last pull's, or hold two
-- pulls fought back to back (measured: the second read repeated the first's hits). The newest session's
-- ID goes with the fight, so the coach can tell a pull read twice.
local function lastSession()
	local sessions = read(api("C_DamageMeter", "GetAvailableCombatSessions"))
	if type(sessions) ~= "table" then return nil end
	-- The highest ID, whatever order the list comes in (not measured yet).
	local id, seconds
	for _, s in ipairs(sessions) do
		if type(s) == "table" and num(s.sessionID) and (not id or s.sessionID > id) then
			id, seconds = s.sessionID, num(s.durationSeconds)
		end
	end
	return id, seconds
end

-- What hit each member of his party, spell by spell and by which mob, and what each interrupted: read by
-- the member's GUID after the fight (Blizzard's meter gives every member's breakdown; measured in a
-- dungeon). The party only, not a raid's forty.
-- Most pulls show fewer; a second read of a merged session (two pulls) holds both pulls' spells.
local MEMBER_SPELLS = 16
local MEMBER_TYPES = { taken = 7, interrupts = 5, avoidable = 8 }
local function members(sourceOf)
	if (num(read(GetNumGroupMembers)) or 0) < 2 or read(IsInRaid) == true then return nil end
	local out = list()
	for _, unit in ipairs({ "player", "party1", "party2", "party3", "party4" }) do
		local guid = read(UnitGUID, unit)
		if type(guid) == "string" then
			local m = { unit = unit, name = read(UnitName, unit), me = unit == "player" or nil }
			for key, meterType in pairs(MEMBER_TYPES) do
				local source = sourceOf(meterType, guid)
				-- A hidden breakdown is left out (unknown), not sent empty (nothing hit them).
				if type(source) == "table" and source ~= ns.SECRET then
					local spells = {}
					for _, sp in ipairs(each(source.combatSpells)) do
						if type(sp) == "table" and num(sp.spellID) then spells[#spells + 1] = sp end
					end
					table.sort(spells, function(a, b) return (num(a.totalAmount) or 0) > (num(b.totalAmount) or 0) end)
					local rows = list()
					for i = 1, math.min(#spells, MEMBER_SPELLS) do
						local sp = spells[i]
						rows[i] = {
							spellID = sp.spellID, name = read(api("C_Spell", "GetSpellName"), sp.spellID),
							amount = sp.totalAmount, from = hitFrom(sp), avoidable = sp.isAvoidable == true or nil,
							cast = key == "taken" and castTime(sp.spellID) or nil,
						}
					end
					m[key] = rows
				end
			end
			out[#out + 1] = m
		end
	end
	return out
end

local function meter()
	local out = {}
	local id, seconds = lastSession()
	local fromType = api("C_DamageMeter", "GetCombatSessionFromType")
	local sourceFromType = api("C_DamageMeter", "GetCombatSessionSourceFromType")
	local fromID = api("C_DamageMeter", "GetCombatSessionFromID")
	local sourceFromID = api("C_DamageMeter", "GetCombatSessionSourceFromID")
	-- By the session's ID when the meter lists them; else the current one (1).
	local function sessionOf(meterType)
		if id and fromID then return read(fromID, id, meterType) end
		return read(fromType, 1, meterType)
	end
	local function sourceOf(meterType, guid)
		if id and sourceFromID then return read(sourceFromID, id, meterType, guid) end
		return read(sourceFromType, 1, meterType, guid)
	end
	local me = read(UnitGUID, "player")
	for name, meterType in pairs(METER) do
		local session = sessionOf(meterType)
		local entry = { total = type(session) == "table" and session.totalAmount or session, seconds = type(session) == "table" and session.durationSeconds or nil }
		if type(session) == "table" then
			-- Every member of his group is a row (the combat module compares them); a name may be secret.
			local sources = list()
			for _, s in ipairs(each(session.combatSources)) do
				if s.isLocalPlayer == true then entry.mine, entry.perSecond = s.totalAmount, s.amountPerSecond end
				-- deathTimeSeconds is always a number; Blizzard's own meter reads it only with a death recap.
				local died = num(s.deathRecapID) and s.deathRecapID ~= 0 and s.deathTimeSeconds or nil
				sources[#sources + 1] = {
					name = s.name, class = s.classFilename, spec = s.specIconID, me = s.isLocalPlayer == true or nil,
					amount = s.totalAmount, perSecond = s.amountPerSecond, died = died,
				}
			end
			entry.sources = sources
		end
		if type(me) == "string" then
			local source = sourceOf(meterType, me)
			if type(source) == "table" then
				local spells = list()
				for _, sp in ipairs(each(source.combatSpells)) do
					spells[#spells + 1] = {
						spellID = sp.spellID, name = num(sp.spellID) and read(api("C_Spell", "GetSpellName"), sp.spellID) or nil,
						amount = sp.totalAmount, from = hitFrom(sp), avoidable = sp.isAvoidable, deadly = sp.isDeadly,
					}
				end
				entry.spells = spells
			end
		end
		out[name] = entry
	end
	out.members = members(sourceOf)
	if id then out.session = { id = id, seconds = seconds } end
	return out
end

-- His long cooldowns (20 s or more), learned from his own casts: the game has no base cooldown to ask for,
-- but after a fight the cooldown of a spell he cast is readable. Kept per character, across sessions.
local LONG_COOLDOWN = 20
local function longCooldowns()
	local db = ForeverCoachDB
	local me = read(UnitGUID, "player")
	if type(db) ~= "table" or type(me) ~= "string" then return {} end
	db.cooldowns = db.cooldowns or {}
	db.cooldowns[me] = db.cooldowns[me] or {}
	return db.cooldowns[me]
end
local function learnCooldowns(casts)
	local known = longCooldowns()
	for _, c in ipairs(casts) do
		local id = num(c.spellID)
		local cd = id and read(api("C_Spell", "GetSpellCooldown"), id)
		if type(cd) == "table" and num(cd.duration) and cd.duration >= LONG_COOLDOWN then known[id] = cd.duration end
	end
end
-- At the pull: which of them are ready. isActive and isOnGCD are never secret, even in combat; a pull opened
-- with an instant has every spell on the global cooldown, which is not the spell's own. Only spells he
-- knows now (not the other spec's, an untalented one, an item's).
local function cooldownsAtPull()
	local out = list()
	local known = api("C_SpellBook", "IsSpellKnown")
	for id, duration in pairs(longCooldowns()) do
		local cd = read(api("C_Spell", "GetSpellCooldown"), id)
		if type(cd) == "table" and type(cd.isActive) == "boolean" and (not known or read(known, id) == true) then
			out[#out + 1] = {
				spellID = id, name = read(api("C_Spell", "GetSpellName"), id), cooldown = duration,
				readyAtStart = not cd.isActive or cd.isOnGCD == true,
			}
		end
	end
	return out
end

-- f is this fight's own record, taken at combat end: the next pull may start a new one
-- while this one still waits for the meter.
local function sendFight(f, seconds, tries)
	if ns.restricted(0) and tries < 20 then
		C_Timer.After(0.5, function() sendFight(f, seconds, tries + 1) end)
		return
	end
	learnCooldowns(f.casts)
	send("fight", { seconds = seconds, target = f.target, casts = f.casts, cooldowns = f.cooldowns, controlled = f.controlled, meter = meter(), waitedForMeter = tries * 0.5 })
end

local combatStart

-- The next party member not read yet (one at a time; a member out of range is tried again a minute later).
function ns.inspectNext()
	if combatStart or inspecting then return end
	for i = 1, 4 do
		local unit = "party" .. i
		local guid = read(UnitGUID, unit)
		if type(guid) == "string" and not inspected[guid] and GetTime() - (tried[guid] or -math.huge) > 60
			and read(CanInspect, unit) == true then
			inspecting, tried[guid] = { guid = guid, unit = unit }, GetTime()
			read(NotifyInspect, unit)
			C_Timer.After(5, function()
				if inspecting and inspecting.guid == guid then inspecting = nil; ns.inspectNext() end
			end)
			return
		end
	end
end
function ns.inspected(guid)
	guid = guard(guid)
	if not inspecting or guid ~= inspecting.guid then return end
	-- The member by GUID now: someone may have left since, and party tokens shift.
	local unit
	for i = 1, 4 do
		if read(UnitGUID, "party" .. i) == guid then unit = "party" .. i end
	end
	if not unit then
		inspecting = nil
		C_Timer.After(1, ns.inspectNext)
		return
	end
	local spec = read(api("C_SpecializationInfo", "GetInspectSpecialization") or GetInspectSpecialization, unit)
	local specName = num(spec) and spec > 0 and select(2, read(GetSpecializationInfoByID, spec)) or nil
	inspected[guid] = { itemLevel = read(api("C_PaperDollInfo", "GetInspectItemLevel"), unit), spec = specName or spec }
	inspecting = nil
	read(ClearInspectPlayer)
	report("group")
	C_Timer.After(1, ns.inspectNext)
end

local function isUnit(unit, want) return guard(unit) == want end

-- Game events -> what to report.
-- Talents cannot change in combat, but a level gained in a fight earns a point: read the tree
-- once it ends rather than walk it mid-fight.
local talentsAfterCombat = false
-- The boss guide was read again for its loot names in this instance (once is enough).
local guideRefreshed = false
-- NPC kinds whose nameplate was seen this session (by npcID).
local sighted = {}
-- The area (zone/subzone) last reported, shared by the zone events and the position tracker: a new area
-- goes within ns.SOON once, not twice, and a zone event that changes nothing waits like any position.
local lastArea
local function areaOf(loc) return tostring(loc.zone) .. "/" .. tostring(loc.subzone) end
local function zoneChanged()
	local area = areaOf(collect.location())
	local changed = lastArea ~= nil and area ~= lastArea
	lastArea = area
	report("location", 0, changed and ns.SOON or nil)
	-- Inside an instance a new area may be a new floor (its map changes): the dungeon's state goes too.
	if changed and read(IsInInstance) == true then report("dungeon", 1, ns.SOON) end
end
local function reportTalents()
	if combatStart then talentsAfterCombat = true else report("talents", 2) end
end

local handlers = {
	PLAYER_ENTERING_WORLD = function() guideRefreshed = false; ns.snapshot(); settleEquipment(0) end,
	PLAYER_TARGET_CHANGED = function() report("target"); report("targetAuras", 0.5) end,
	UNIT_HEALTH = function(unit)
		if isUnit(unit, "target") then report("target", 0.5) elseif isUnit(unit, "player") then report("vitals", 1) end
	end,
	UNIT_POWER_UPDATE = function(unit) if isUnit(unit, "player") then report("vitals", 1) end end,
	UNIT_AURA = function(unit) if isUnit(unit, "target") then report("targetAuras", 1) end end,
	UNIT_SPELLCAST_START = function(unit) if isUnit(unit, "target") then report("targetCast") end end,
	UNIT_SPELLCAST_SUCCEEDED = function(unit, _, spellID)
		if not isUnit(unit, "player") then return end
		local id = guard(spellID)
		local cast = { at = ns.now(), spellID = id, name = num(id) and read(api("C_Spell", "GetSpellName"), id) or nil }
		-- How long it held him (a cast time; instants are 0 and take the global cooldown).
		local info = num(id) and read(api("C_Spell", "GetSpellInfo"), id)
		if type(info) == "table" and num(info.castTime) then cast.castTime = info.castTime / 1000 end
		if not combatStart then
			precasts[#precasts + 1] = cast
			while precasts[1] and cast.at - precasts[1].at > PRECAST do table.remove(precasts, 1) end
			return
		end
		if #fight.casts >= MAX_CASTS then return end
		cast.t = math.floor((cast.at - combatStart) * 100) / 100
		fight.casts[#fight.casts + 1] = cast
	end,
	UNIT_THREAT_LIST_UPDATE = function(unit) if isUnit(unit, "target") then report("threat", 1) end end,
	-- Stunned, silenced, feared… during a fight: what did it, and for how long (his own only: another
	-- member's is not shown; measured in Uldaman, 2026-10-21).
	LOSS_OF_CONTROL_ADDED = function(unit, index)
		if not combatStart or not isUnit(unit, "player") or #fight.controlled >= MAX_CONTROLLED then return end
		local d = read(api("C_LossOfControl", "GetActiveLossOfControlData"), guard(index))
		if type(d) ~= "table" or not num(d.spellID) then return end
		fight.controlled[#fight.controlled + 1] = {
			type = d.locType, spellID = d.spellID, name = read(api("C_Spell", "GetSpellName"), d.spellID),
			seconds = d.duration, t = math.floor((ns.now() - combatStart) * 100) / 100,
		}
	end,
	-- Combat start and end, with whom: the coach keeps the fight's clock from here.
	PLAYER_REGEN_DISABLED = function()
		combatStart = ns.now()
		ns.inCombat = true
		fight = { casts = list(), target = recentTarget(), cooldowns = cooldownsAtPull(), controlled = list() }
		for _, c in ipairs(precasts) do
			if combatStart - c.at <= PRECAST then
				c.t = math.floor((c.at - combatStart) * 100) / 100
				fight.casts[#fight.casts + 1] = c
			end
		end
		precasts = {}
		send("combat", { event = "start", target = describe("target"), lastKnownTarget = recentTarget(), lastTargetAge = targetAge() })
	end,
	PLAYER_REGEN_ENABLED = function()
		ns.inCombat = false
		local seconds = combatStart and math.floor((ns.now() - combatStart) * 10) / 10 or nil
		send("combat", { event = "end", seconds = seconds })
		combatStart = nil
		report("player")
		if talentsAfterCombat then talentsAfterCombat = false; report("talents", 2) end
		local finished = fight
		fight = { casts = list(), controlled = list() }
		sendFight(finished, seconds, 0)
		ns.inspectNext()
	end,
	ADDON_RESTRICTION_STATE_CHANGED = function(kind, state)
		kind, state = guard(kind), guard(state)
		if num(kind) then ns.restrictionState[kind] = state end
		report("restrict")
	end,
	ZONE_CHANGED = zoneChanged,
	ZONE_CHANGED_INDOORS = zoneChanged,
	ZONE_CHANGED_NEW_AREA = function() zoneChanged(); report("vignettes", 2); report("questmap", 2) end,
	-- The game's answer to the request; requestRequired says what it holds is stale: asked again, as
	-- Blizzard's own world map does (QuestOfferDataProvider).
	QUESTLINE_UPDATE = function(requestRequired)
		if guard(requestRequired) == true then questLinesFor = nil end
		report("questmap", 2)
	end,
	-- An item the game had not described yet (not cached) now is: the gear it is in, again.
	GET_ITEM_INFO_RECEIVED = function()
		report("bags", 3); report("equipment", 3)
		-- The guide's loot names, once the game has them: one more read per instance, not one per item.
		if read(IsInInstance) == true and not guideRefreshed then
			guideRefreshed = true
			report("bossguide", 10)
		end
	end,
	PLAYER_XP_UPDATE = function() report("player", 1) end,
	PLAYER_LEVEL_UP = function() report("player", 0, ns.SOON) end,
	-- After the level has changed (UnitLevel may still say the old one during PLAYER_LEVEL_UP).
	PLAYER_LEVEL_CHANGED = function() report("player", 0, ns.SOON) end,
	PLAYER_MONEY = function() report("player", 1) end,
	UPDATE_EXHAUSTION = function() report("player", 5) end,
	PLAYER_UPDATE_RESTING = function() report("player", 1) end,
	HEARTHSTONE_BOUND = function() report("player") end,
	CHAT_MSG_COMBAT_XP_GAIN = function(text) send("xpgain", { text = clean(text) }, { lazy = true }) end,
	QUEST_LOG_UPDATE = function() report("quests", 2); report("questmap", 5) end,
	QUEST_DETAIL = function() report("questoffer") end,
	QUEST_PROGRESS = function() report("questprogress") end,
	QUEST_COMPLETE = function() report("questcomplete") end,
	-- An accept or a turn-in changes what the map offers: the game's quest lines are asked for again (asked
	-- once per map, they stayed stale: a quest turned in was still offered minutes later).
	QUEST_ACCEPTED = function(questID)
		send("questevent", { event = "accepted", questID = clean(questID) })
		questLinesFor = nil
		report("questmap", 2)
	end,
	QUEST_TURNED_IN = function(questID, xp, money)
		send("questevent", { event = "turnedIn", questID = clean(questID), xp = clean(xp), money = clean(money) })
		questLinesFor = nil
		report("questmap", 2)
	end,
	-- Abandoned (or turned in): what it held back may be offered again.
	QUEST_REMOVED = function()
		questLinesFor = nil
		report("questmap", 2)
	end,
	GOSSIP_SHOW = function() report("gossip") end,
	MERCHANT_SHOW = function() report("merchant") end,
	TRAINER_SHOW = function() report("trainer") end,
	TAXIMAP_OPENED = function() report("taxi") end,
	LOOT_OPENED = function() report("loot") end,
	CHAT_MSG_LOOT = function(text) send("lootmsg", { text = clean(text) }, { lazy = true }) end,
	PLAYER_EQUIPMENT_CHANGED = function() report("equipment", 1) end,
	-- His inventory loaded or changed (also when the game loads his gear late, after the retries).
	UNIT_INVENTORY_CHANGED = function(unit) if isUnit(unit, "player") then report("equipment", 2) end end,
	UPDATE_INVENTORY_DURABILITY = function() report("equipment", 5) end,
	BAG_UPDATE_DELAYED = function() report("bags", 2) end,
	TRADE_SKILL_SHOW = function() report("profession") end,
	PLAYER_SPECIALIZATION_CHANGED = function() report("spec", 1); reportTalents() end,
	ACTIVE_TALENT_GROUP_CHANGED = function() report("spec", 1); reportTalents() end,
	-- Talents change while he clicks through the tree: one report once it settles.
	TRAIT_CONFIG_UPDATED = function() reportTalents() end,
	-- Other trees (skyriding, professions) fire it too: only the talent tree's, out of combat.
	TRAIT_TREE_CURRENCY_INFO_UPDATED = function(treeID)
		if not talentTree or guard(treeID) == talentTree then reportTalents() end
	end,
	PLAYER_TALENT_UPDATE = function() reportTalents() end,
	ACTIVE_COMBAT_CONFIG_CHANGED = function() reportTalents() end,
	VIGNETTES_UPDATED = function() report("vignettes", 2) end,
	PLAYER_DEAD = function() send("death", { event = "dead", lastKnownTarget = recentTarget(), lastTargetAge = targetAge(), location = collect.location() }) end,
	PLAYER_ALIVE = function() send("death", { event = "alive" }) end,
	PLAYER_UNGHOST = function() send("death", { event = "unghost" }) end,
	-- The first nameplate of a hostile or neutral kind of NPC goes at once: the coach can brief the pull
	-- before he targets it (a median 6.7 s earlier, latency research 2026-10-19). Later ones wait.
	NAME_PLATE_UNIT_ADDED = function(unit)
		local d = describe(unit)
		d.token, d.op = clean(unit), "added"
		local new = num(d.npcID) and not sighted[d.npcID] and num(d.reaction) and d.reaction <= 4
		if new then sighted[d.npcID] = true end
		-- Within 2 s: new kinds coming into view together share one write (the lead is ~6.7 s).
		send("unit", d, { lazy = not new, within = new and 2 or nil })
	end,
	NAME_PLATE_UNIT_REMOVED = function(unit) send("unit", { token = clean(unit), op = "removed" }, { lazy = true }) end,
	ENCOUNTER_START = function(id, name, difficulty, size)
		send("encounter", { event = "start", id = clean(id), name = clean(name), difficulty = clean(difficulty), size = clean(size),
			target = describe("target"), lastKnownTarget = recentTarget(), lastTargetAge = targetAge() })
	end,
	SCENARIO_CRITERIA_UPDATE = function() if read(IsInInstance) == true then report("dungeon", 2, ns.SOON) end end,
	ENCOUNTER_END = function(id, name, difficulty, size, success)
		send("encounter", { event = "end", id = clean(id), name = clean(name), difficulty = clean(difficulty), size = clean(size), success = clean(success) })
		report("dungeon", 1, ns.SOON) -- progress: which bosses are down
	end,
	ENCOUNTER_WARNING = function(info) send("warning", { info = clean(info) }) end,
	-- His group: who is in it, and (by inspect, out of combat) each member's item level and spec.
	GROUP_ROSTER_UPDATE = function() report("group", 1); ns.inspectNext() end,
	PARTY_LEADER_CHANGED = function() report("group", 1) end,
	INSPECT_READY = function(guid) ns.inspected(guid) end,
	ENCOUNTER_TIMELINE_EVENT_ADDED = function(info) send("timeline", { info = clean(info) }) end,
}

-- Unit events, registered only for the units they are read for.
local UNIT_EVENTS = {
	UNIT_HEALTH = { "target", "player" }, UNIT_POWER_UPDATE = { "player" }, UNIT_AURA = { "target" },
	UNIT_SPELLCAST_START = { "target" }, UNIT_SPELLCAST_SUCCEEDED = { "player" },
	UNIT_THREAT_LIST_UPDATE = { "target" }, PLAYER_SPECIALIZATION_CHANGED = { "player" },
}

-- Position, while moving: checked every 3 s, sent (lazily) when it moved ~5 yards; within ns.SOON when
-- the zone or subzone changed (a new area makes a moment; the game's ZONE_CHANGED events do too).
local lastPos = ""
local function trackPosition()
	local loc = collect.location()
	local key = tostring(loc.mapID) .. ":" .. tostring(num(loc.x) and math.floor(loc.x * 200)) .. ":" .. tostring(num(loc.y) and math.floor(loc.y * 200))
	if key ~= lastPos then
		lastPos = key
		local area = areaOf(loc)
		local moved = lastArea ~= nil and area ~= lastArea
		lastArea = area
		send("location", loc, { lazy = not moved, within = moved and ns.SOON or nil })
	end
end

local frame = CreateFrame("Frame")
frame:SetScript("OnEvent", function(self, event, ...)
	if event == "ADDON_LOADED" then
		if ... ~= ADDON then return end
		ForeverCoachDB = ForeverCoachDB or {}
		ForeverCoachDB.stats = ns.stats
		self:UnregisterEvent("ADDON_LOADED")
		self:SetScript("OnUpdate", function(f, elapsed)
			if ns.calibrate(f, elapsed) then f:SetScript("OnUpdate", nil) end
		end)
		C_Timer.NewTicker(3, trackPosition)
		-- Within 10 s, not the 30 s cosmetic wait: beats reach the file at most ~70 s apart, which coach-link
		-- relies on (a quiet log for 90 s is a closed game: SWITCH_QUIET).
		C_Timer.NewTicker(60, function() report("heartbeat", 0, 10) end)
		-- In a group, between pulls: who wears which buff (only a change is written).
		C_Timer.NewTicker(10, function()
			if not combatStart and not ns.inCombat and (num(read(GetNumGroupMembers)) or 0) > 0 then report("group") end
		end)
		return
	end
	local handler = handlers[event]
	if handler then
		local ok, err = pcall(handler, ...)
		if not ok then send("error", { event = event, error = tostring(err) }, { dedupe = true }) end
	end
end)
frame:RegisterEvent("ADDON_LOADED")
for event in pairs(handlers) do
	local units = UNIT_EVENTS[event]
	if units and frame.RegisterUnitEvent then
		pcall(frame.RegisterUnitEvent, frame, event, unpack(units))
	else
		pcall(frame.RegisterEvent, frame, event)
	end
end
