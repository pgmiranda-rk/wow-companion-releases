-- ForeverCoach core: guards, JSON, and the sender.
--
-- The only live way out of an addon is C_Log into Logs/General.log, which the client
-- buffers 48 KB at a time (phase1-results). A send therefore writes its lines and then
-- enough padding to overflow the buffer, so the coach on the PC reads it within ~0.1 s.
--
-- Urgent sends (a new target, combat, a quest dialog, loot) share one forced write within
-- 0.25 s; what makes a moment (quest log, bags, talents, a level, a new area) within 1 s;
-- cosmetic state (vitals, threat, heartbeat, position drift) waits up to 30 s for the next
-- write. Nothing is dropped except exact repeats; disk use is not a constraint (Pedro).
-- Measured on retail: about 27 MB an hour of active questing.
--
-- Frame: COACH1 <seq> <epoch> <kind> <part>/<parts> <mask> <json chunk>
--   mask: which addon restrictions were active when it was sent (bit n = type n:
--   0 combat, 1 encounter, 2 challenge mode, 3 PvP match, 4 map, 5 chat).
-- A secret value is never sent: it becomes {"secret":true}. C_Log would refuse it anyway.

local _, ns = ...

ns.SECRET = setmetatable({}, { __tostring = function() return "<secret>" end })

local COALESCE = 0.25 -- seconds an urgent send waits for others to share its forced write
local LAZY = 30 -- seconds cosmetic state (vitals, threat, heartbeat, position drift) may wait
-- What makes a moment (an objective, an item in the bags, a level, a new area) is not cosmetic: it goes
-- within ns.SOON. Measured on a recorded session (latency research, 2026-10-19): with 10 s for all lazy
-- kinds, one in ten objectives waited ~10 s; with these two, p90 1 s at the same writes per hour.
ns.SOON = 1
local MIN_GAP = 0.5 -- at most two forced writes a second
local CHUNK = 3500 -- the client cuts a log line at ~4 KB
local PAD_LINES = 13 -- 13 x ~4.1 KB lines always overflow the 48 KB buffer
local PAD = string.rep("z", 4000)
local MAX_DEPTH = 6

-- A value as the coach may see it: itself, or SECRET.
function ns.guard(v)
	if issecretvalue and issecretvalue(v) then return ns.SECRET end
	return v
end

-- A deep copy with every secret replaced by SECRET (secret keys are dropped).
function ns.clean(v, depth)
	v = ns.guard(v)
	if type(v) ~= "table" or v == ns.SECRET then return v end
	depth = (depth or 0) + 1
	if depth > MAX_DEPTH then return "<too deep>" end
	local out = {}
	for k, x in pairs(v) do
		k = ns.guard(k)
		if k ~= ns.SECRET and type(k) ~= "table" then out[k] = ns.clean(x, depth) end
	end
	return out
end

local function escape(s)
	return (s:gsub('[%c"\\]', function(c)
		if c == '"' then return '\\"' end
		if c == "\\" then return "\\\\" end
		if c == "\n" then return "\\n" end
		if c == "\t" then return "\\t" end
		return string.format("\\u%04x", c:byte())
	end))
end

-- Marks a table as a JSON array, so an empty one is sent as [] rather than {}.
local LIST = {}
function ns.list(t) return setmetatable(t or {}, LIST) end

local function isArray(t)
	local n = 0
	for _ in pairs(t) do n = n + 1 end
	return n > 0 and n == #t
end

local encode
function encode(v, depth)
	depth = depth or 0
	if v == ns.SECRET then return '{"secret":true}' end
	local t = type(v)
	if v == nil then return "null" end
	if t == "boolean" then return tostring(v) end
	if t == "number" then
		if v ~= v or v == math.huge or v == -math.huge then return "null" end
		if v == math.floor(v) and math.abs(v) < 2 ^ 53 then return string.format("%.0f", v) end
		-- Epoch times keep their milliseconds; %.10g would round them to the second.
		if math.abs(v) >= 1e9 then return string.format("%.3f", v) end
		return string.format("%.10g", v)
	end
	if t == "string" then return '"' .. escape(v) .. '"' end
	if t ~= "table" or depth >= MAX_DEPTH then return '"' .. escape(tostring(v)) .. '"' end
	local parts = {}
	if getmetatable(v) == LIST or isArray(v) then
		for i = 1, #v do parts[i] = encode(v[i], depth + 1) end
		return "[" .. table.concat(parts, ",") .. "]"
	end
	local keys = {}
	for k in pairs(v) do keys[#keys + 1] = k end
	table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
	for _, k in ipairs(keys) do
		parts[#parts + 1] = '"' .. escape(tostring(k)) .. '":' .. encode(v[k], depth + 1)
	end
	return "{" .. table.concat(parts, ",") .. "}"
end
ns.encode = encode

-- Epoch with sub-second precision (as in CoachProbe): pin GetTimePreciseSec() to the
-- moment time() ticks over, on a short frame so a loading hitch cannot skew it.
local clock = {}
function ns.now()
	if clock.base then return clock.base + (GetTimePreciseSec() - clock.precise) end
	return time()
end

-- Each missed tick-over (seen at the end of a frame too long to trust) doubles what counts
-- as short, so a slow machine still calibrates within a few seconds.
local shortFrame = 0.05
function ns.calibrate(_, elapsed)
	local t = time()
	if clock.last and t ~= clock.last and GetTimePreciseSec then
		if (elapsed or 0) <= shortFrame then
			clock.base, clock.precise = t, GetTimePreciseSec()
			return true
		end
		shortFrame = math.min(shortFrame * 2, 1)
	end
	clock.last = t
	return false
end

-- Restriction state as last announced by ADDON_RESTRICTION_STATE_CHANGED (type -> state,
-- 0 = inactive). The API reports false while that event is dispatched, and the event fires
-- before the restriction applies, so both sources are combined.
ns.restrictionState = {}

function ns.restricted(kind)
	local s = ns.restrictionState[kind]
	if type(s) == "number" and s ~= 0 then return true end
	local active = C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive
	if not active then return false end
	local ok, on = pcall(active, kind)
	return ok and ns.guard(on) == true
end

function ns.restrictionMask()
	local mask = 0
	for kind = 0, 5 do
		if ns.restricted(kind) then mask = mask + 2 ^ kind end
	end
	return mask
end

-- Splits s into pieces of at most `size` bytes without cutting a UTF-8 character.
local function chunks(s, size)
	local out, i = {}, 1
	while i <= #s do
		local j = math.min(i + size - 1, #s)
		while j < #s and j > i and s:byte(j + 1) >= 0x80 and s:byte(j + 1) < 0xC0 do j = j - 1 end
		out[#out + 1] = s:sub(i, j)
		i = j + 1
	end
	if #out == 0 then out[1] = "" end
	return out
end
ns.chunks = chunks

local queue, flushAt, lastFlush = {}, nil, -math.huge
-- logFailed / firstLogError / lastLogError(At) / lastLogOkAt: what the game answered when a log call
-- failed (the writes once stopped mid-session until a /reload, with the error discarded). Saved with
-- ForeverCoachDB at the next /reload or logout.
ns.stats = { sends = 0, skipped = 0, flushes = 0, lines = 0, maxFlushMs = 0, byKind = {}, logFailed = 0 }
local seq = 0
local lastData = {}

local function flush()
	flushAt = nil
	local log = C_Log and C_Log.LogMessage
	if not log or #queue == 0 then return end
	local t0 = debugprofilestop and debugprofilestop()
	local stats = ns.stats
	local function write(line)
		local ok, err = pcall(log, line)
		if ok then
			stats.lastLogOkAt = time()
		else
			stats.logFailed = stats.logFailed + 1
			-- The game's answer as text: never a secret, never raising, at most 500 characters.
			local shown, text = pcall(tostring, ns.guard(err))
			text = shown and type(text) == "string" and text:sub(1, 500) or "<unreadable>"
			stats.lastLogError, stats.lastLogErrorAt = text, time()
			stats.firstLogError = stats.firstLogError or stats.lastLogError
			stats.firstLogErrorAt = stats.firstLogErrorAt or stats.lastLogErrorAt
		end
	end
	for _, line in ipairs(queue) do write(line) end
	for _ = 1, PAD_LINES do write(PAD) end
	ns.stats.lines = ns.stats.lines + #queue
	ns.stats.flushes = ns.stats.flushes + 1
	if t0 then ns.stats.maxFlushMs = math.max(ns.stats.maxFlushMs, debugprofilestop() - t0) end
	queue = {}
	lastFlush = GetTime()
end
ns.flush = flush

-- Plans a forced write within `delay` seconds (never sooner than MIN_GAP after the last).
-- An earlier plan wins; a timer that finds its plan superseded does nothing.
local function schedule(delay)
	local at = math.max(GetTime() + delay, lastFlush + MIN_GAP)
	if flushAt and flushAt <= at then return end
	flushAt = at
	C_Timer.After(at - GetTime(), function()
		if flushAt and GetTime() + 1e-6 >= flushAt then flush() end
	end)
end

-- Queues one message. opts.lazy: it may wait up to LAZY seconds for the next write; opts.within: at most
-- that many seconds (ns.SOON for what makes a moment).
-- opts.dedupe: skipped when identical to the last message of its kind.
function ns.send(kind, payload, opts)
	opts = opts or {}
	local data = encode(payload)
	if opts.dedupe then
		if lastData[kind] == data then
			ns.stats.skipped = ns.stats.skipped + 1
			return false
		end
		lastData[kind] = data
	end
	seq = seq + 1
	local mask = ns.restrictionMask()
	local parts = chunks(data, CHUNK)
	local head = "COACH1 " .. seq .. " " .. string.format("%.3f", ns.now()) .. " " .. kind .. " "
	for i, piece in ipairs(parts) do
		queue[#queue + 1] = head .. i .. "/" .. #parts .. " " .. mask .. " " .. piece
	end
	ns.stats.sends = ns.stats.sends + 1
	ns.stats.byKind[kind] = (ns.stats.byKind[kind] or 0) + 1
	schedule(opts.within or (opts.lazy and LAZY or COALESCE))
	return true
end
