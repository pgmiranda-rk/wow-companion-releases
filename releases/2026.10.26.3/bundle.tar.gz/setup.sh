#!/bin/sh
# The release's own installer (deploy/README.md, "A fresh machine"), run by install.sh from the unpacked
# bundle: the data volume, the server and the client beside the game as they run today, the add-on in the
# game, and a check that the coach answers. Safe to run again: it brings everything to the current version.
#   install   (default)
#   help
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
cmd=${1:-install}
[ $# -eq 0 ] || shift

wow="D:/Jogos/World of Warcraft"
network=k3d-control-plane
bridge_key=""
ci=1
addon=1
while [ $# -gt 0 ]; do
  case "$1" in
    --wow) wow=${2:?--wow needs the game folder}; shift 2 ;;
    --network) network=${2:?--network needs a Docker network}; shift 2 ;;
    --bridge-key) bridge_key=${2:?--bridge-key needs a public key}; shift 2 ;;
    --no-ci) ci=0; shift ;;
    --no-addon) addon=0; shift ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

say() { printf '%s\n' "$*"; }
die() { printf 'error: %s\n' "$*" >&2; exit 1; }
vol=wow-coach
tools=alpine:3.20

usage() {
  cat <<USAGE
install [--wow DIR] [--network NAME] [--bridge-key "ssh-ed25519 ..."] [--no-ci] [--no-addon]
  --wow         the game's folder, as Docker Desktop sees it (default $wow)
  --network     the control plane's Docker network (default $network); install the control plane first
  --bridge-key  a builder's public key: also starts wow-bridge, the builder's door (SSH on 2222)
  --no-ci       leave the CI runner out (it starts by default and waits for the builder to register it: tools/ci-register.sh)
  --no-addon    leave the game's folder alone
USAGE
}

case "$cmd" in
  help|-h|--help) usage; exit 0 ;;
  install) ;;
  *) usage >&2; exit 2 ;;
esac

docker info >/dev/null 2>&1 || die "no Docker here: mount its socket (-v /var/run/docker.sock:/var/run/docker.sock)"

# --- install ---
docker compose version >/dev/null 2>&1 || apk add --no-cache docker-cli-compose >/dev/null || die "no docker compose"
docker network inspect "$network" >/dev/null 2>&1 \
  || die "no Docker network $network: install the control plane first (the companion reaches the coach on it), or pass --network"

# Addresses on that network: .200 server, .201 bridge, .202 client, as today.
subnet=$(docker network inspect -f '{{range .IPAM.Config}}{{.Subnet}} {{end}}' "$network" | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/' | head -1)
[ -n "$subnet" ] || die "$network has no IPv4 subnet"
mask=${subnet#*/}
IFS=. read -r a b c _ <<EOF2
${subnet%/*}
EOF2
if [ "$mask" -le 16 ]; then base="$a.$b.0"; else base="$a.$b.$c"; fi
COACH_SERVER_IP="$base.200"
COACH_BRIDGE_IP="$base.201"
COACH_CLIENT_IP="$base.202"
export COACH_NETWORK="$network" COACH_SERVER_IP COACH_BRIDGE_IP COACH_CLIENT_IP WOW_DIR="$wow"
export COACH_SERVER="http://$COACH_SERVER_IP:7710"

# The game folder, before anything starts: a bind of a folder the daemon cannot see is made empty, and the
# client would watch nothing. --mount takes a Windows path (D:/...) that -v would split at its colon.
docker run --rm --mount "type=bind,source=$wow,target=/wow,readonly" "$tools" sh -c 'ls -d /wow/_*_ >/dev/null 2>&1' \
  || die "no game folder at $wow as Docker sees it (it holds _retail_ / _forever_): pass --wow, and share the drive with Docker (deploy/OPERATING.md)"
docker volume create "$vol" >/dev/null
# The folders each container mounts (a volume's subpath must exist), owned by the user the coach runs as.
# ci/ and watchtower/ too: the builder writes them through the bridge (as that user).
docker run --rm -v "$vol:/v" "$tools" sh -c \
  'mkdir -p /v/coach/players /v/coach/reference /v/refresh /v/watchtower /v/ci /v/ssh_host_keys &&
   chown -R 1000:1000 /v/coach /v/refresh /v/ci /v/watchtower'
# The bridge's SSH host keys: its image makes them only when their folder is missing, and the folder has to
# exist for the mount, so they are made here, once.
if [ -n "$bridge_key" ]; then
  docker run --rm -v "$vol:/v" "$tools" sh -c \
    'ls /v/ssh_host_keys/ssh_host_*_key >/dev/null 2>&1 || {
       apk add -q --no-cache openssh-keygen >/dev/null && mkdir -p /tmp/k/etc/ssh && ssh-keygen -A -f /tmp/k &&
       cp /tmp/k/etc/ssh/ssh_host_* /v/ssh_host_keys/; }'
fi

profiles=""
if [ -n "$bridge_key" ]; then
  profiles="bridge"
  export BRIDGE_PUBLIC_KEY="$bridge_key"
fi
if [ "$ci" = 1 ]; then
  profiles="${profiles:+$profiles,}ci"
  for v in wow-coach_ci-runner wow-coach_ci-cargo wow-coach_ci-rustup; do docker volume create "$v" >/dev/null; done
  tar -C "$HERE" -cf - ci-runner.sh | docker run --rm -i -v "$vol:/v" "$tools" sh -c 'tar -C /v/ci -xf - && chmod 755 /v/ci/ci-runner.sh'
fi
export COMPOSE_PROFILES="$profiles"

say "server: pulling and starting"
docker compose -f "$HERE/server.yaml" up -d --pull always
say "client: pulling and starting"
docker compose -f "$HERE/client.yaml" -f "$HERE/profiles.yaml" up -d --pull always

if [ "$addon" = 1 ]; then
  # Only Interface/AddOns/ForeverCoach of each flavor that has the game in it (a flavor never launched has
  # no WTF yet): a /reload in game loads it.
  tar -C "$HERE/addon" -cf - . | docker run --rm -i --mount "type=bind,source=$wow,target=/wow" "$tools" sh -c '
    mkdir -p /tmp/a && tar -C /tmp/a -xf - && n=0
    for d in /wow/_*_; do
      { [ -d "$d/Interface" ] || [ -d "$d/WTF" ]; } || continue
      mkdir -p "$d/Interface/AddOns/ForeverCoach" && cp -R /tmp/a/. "$d/Interface/AddOns/ForeverCoach/" && echo "addon: ${d#/wow/}" && n=$((n+1))
    done
    [ "$n" -gt 0 ] || { echo "no game flavor found in /wow: is --wow right?" >&2; exit 1; }'
fi

# The coach answers, and the client is following the game.
i=0
until docker run --rm --network "$network" "$tools" wget -qO- "$COACH_SERVER/version" 2>/dev/null; do
  i=$((i+1)); [ "$i" -lt 30 ] || die "the coach does not answer at $COACH_SERVER (docker logs coach-server)"
  sleep 2
done
echo
for c in coach-server coach-refresher coach-client watchtower; do
  [ "$(docker inspect -f '{{.State.Running}}' "$c" 2>/dev/null)" = true ] || die "$c is not running (docker logs $c)"
done
say "running: coach-server, coach-refresher, coach-client, watchtower"
say
say "Done. The companion's coach is at $COACH_SERVER/p/pedro/mcp"
[ "$COACH_SERVER_IP" = "172.20.0.200" ] || say "That is not 172.20.0.200: point the companion's profile (the coach connector) at it."
say "In game: /reload, so the add-on loads."
