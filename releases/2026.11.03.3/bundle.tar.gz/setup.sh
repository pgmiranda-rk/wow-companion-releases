#!/bin/sh
# The release's own installer (deploy/README.md, "A fresh machine"), run by install.sh from the unpacked
# bundle: the data volume, the server and the client beside the game as they run today, the add-on in the
# game, and a check that the coach answers. Safe to run again: it brings everything to the current version.
#   install   (default)
#   help
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
cmd=${1:-install}
[ $# -eq 0 ] || shift

wow=""
network=""
bridge_key=""
ci=""
addon=1
while [ $# -gt 0 ]; do
  case "$1" in
    "") echo "let Docker see the game's folder: Docker Desktop, Settings, Resources, File sharing (on a Mac add /Applications, on Windows its drive)" ;;
    --wow) wow=${2:?--wow needs the game folder}; shift 2 ;;
    --network) network=${2:?--network needs a Docker network}; shift 2 ;;
    --bridge-key) bridge_key=${2:?--bridge-key needs a public key}; shift 2 ;;
    --ci) ci=1; shift ;;
    --no-ci) ci=0; shift ;;
    --no-addon) addon=0; shift ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

say() { printf '%s\n' "$*"; }
die() { printf 'error: %s\n' "$*" >&2; exit 1; }
vol=wow-coach
tools=alpine:3.20

usage() {
  cat <<USAGE
install [--wow DIR] [--network NAME] [--bridge-key "ssh-ed25519 ..."] [--ci | --no-ci] [--no-addon]
  --wow         the game's folder, the one holding _retail_ / _forever_ (default: the last install's, else
                asked, offering the first usual place that has the game)
  --network     the Docker network to join (default: the control plane's, k3d-control-plane, when it is
                there; otherwise one of its own, wow-coach). Claude Code on this computer: http://localhost:7710
  --bridge-key  a builder's public key: also starts wow-bridge, the builder's door (SSH on 2222)
  --ci, --no-ci the CI runner, for the coach's builder (default: on beside the control plane, else off;
                it waits for the builder to register it: tools/ci-register.sh)
  --no-addon    leave the game's folder alone
USAGE
}

case "$cmd" in
  help|-h|--help) usage; exit 0 ;;
  install) ;;
  *) usage >&2; exit 2 ;;
esac

docker info >/dev/null 2>&1 || die "no Docker here: mount its socket (-v /var/run/docker.sock:/var/run/docker.sock)"

# --- install ---
docker compose version >/dev/null 2>&1 || apk add --no-cache docker-cli-compose >/dev/null || die "no docker compose"
# The network: the one named, the control plane's when it is there (its sandboxes reach the coach on it),
# or one of the coach's own. Everything on it finds the coach by name, coach-server: a fresh network's
# addresses differ, its names do not.
if [ -z "$network" ]; then
  if docker network inspect k3d-control-plane >/dev/null 2>&1; then network=k3d-control-plane
  else network=wow-coach; fi
fi
if ! docker network inspect "$network" >/dev/null 2>&1; then
  [ "$network" = wow-coach ] || die "no Docker network $network"
  docker network create wow-coach >/dev/null
fi
[ -n "$ci" ] || { [ "$network" = k3d-control-plane ] && ci=1 || ci=0; }
export COACH_NETWORK="$network" WOW_DIR="$wow"
export COACH_SERVER="http://coach-server:7710"

# Beside the control plane, the coach's containers keep the high addresses they always had (.200 server,
# .201 bridge, .202 client): nothing reaches them by address, but taking the lowest free ones could take one
# the cluster's own containers come back to after a restart. Their own network needs none of this.
srv_extra="" cli_extra=""
if [ "$network" = k3d-control-plane ]; then
  subnet=$(docker network inspect -f '{{range .IPAM.Config}}{{.Subnet}} {{end}}' "$network" | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/' | head -1)
  [ -n "$subnet" ] || die "$network has no IPv4 subnet"
  mask=${subnet#*/}
  IFS=. read -r a b c _ <<EOF2
${subnet%/*}
EOF2
  if [ "$mask" -le 16 ]; then base="$a.$b.0"; else base="$a.$b.$c"; fi
  printf 'services:\n  coach-server:\n    networks:\n      cluster:\n        ipv4_address: %s.200\n' "$base" >"$HERE/addresses-server.yaml"
  printf 'services:\n  coach-client:\n    networks:\n      cluster:\n        ipv4_address: %s.202\n  wow-bridge:\n    networks:\n      cluster:\n        ipv4_address: %s.201\n' "$base" "$base" >"$HERE/addresses-client.yaml"
  srv_extra="-f $HERE/addresses-server.yaml" cli_extra="-f $HERE/addresses-client.yaml"
fi

# The game folder, before anything starts: a bind of a folder the daemon cannot see is made empty, and the
# client would watch nothing. --mount takes a Windows path (D:/...) that -v would split at its colon.
# The source quoted: --mount reads its value as CSV, and a folder's name may hold a comma.
has_game() {
  [ -n "$1" ] && docker run --rm --mount "type=bind,\"source=$1\",target=/wow,readonly" "$tools" \
    sh -c 'ls -d /wow/_*_ >/dev/null 2>&1' 2>/dev/null
}
# As the player types it: C:\Program Files (x86)\World of Warcraft, with or without quotes.
as_docker_path() {
  printf '%s' "$1" | tr '\\' / | sed -e "s/^[[:space:]\"']*//" -e "s/[[:space:]\"']*\$//" -e 's#/*$##'
}
# How to let Docker see a folder: a Mac's Docker Desktop shares /Users, /Volumes, /private and /tmp, not
# /Applications, where the game installs; on Windows, a drive is shared or not.
share_hint() {
  case "$1" in
    "") echo "let Docker see the game's folder: Docker Desktop, Settings, Resources, File sharing (on a Mac add /Applications, on Windows its drive)" ;;
    /Users/*|/Volumes/*|/private/*|/tmp/*) echo "is it the folder holding _retail_ / _forever_?" ;;
    /*) echo "on a Mac, let Docker see it: Docker Desktop, Settings, Resources, File sharing, add ${1%%/World of Warcraft*}, Apply" ;;
    *) echo "on Windows, let Docker see its drive: Docker Desktop, Settings, Resources, File sharing" ;;
  esac
}
# Where it asks: the terminal (the script itself comes through a pipe). The test points it at a file.
tty=${COACH_TTY:-/dev/tty}
if [ -z "$wow" ]; then
  # The last install's, kept in the volume: an upgrade asks nothing.
  last=$(docker run --rm -v "$vol:/v" "$tools" sh -c 'cat /v/install/wow 2>/dev/null' || true)
  if has_game "$last"; then
    wow=$last
    say "game folder: $wow (the last install's; --wow to change it)"
  else
    found=""
    for d in "C:/Program Files (x86)/World of Warcraft" "C:/Program Files/World of Warcraft" \
      "D:/World of Warcraft" "D:/Games/World of Warcraft" "D:/Program Files (x86)/World of Warcraft" \
      "E:/World of Warcraft" "/Applications/World of Warcraft"; do
      if has_game "$d"; then found=$d; break; fi
    done
    # Asked on the terminal (prompts on stderr, which is the terminal too); without one, what was found.
    # Five tries; no answer at all (Ctrl-D, a terminal gone) takes what was found, or stops.
    if (exec <"$tty") 2>/dev/null; then
      tries=0
      while :; do
        printf 'World of Warcraft folder, the one holding _retail_ / _forever_%s: ' "${found:+ [$found]}" >&2
        if ! read -r answer <"$tty"; then
          [ -n "$found" ] || die "no game folder given: pass --wow \"<the folder holding _retail_ / _forever_>\""
          answer=""
        fi
        wow=$(as_docker_path "${answer:-$found}")
        has_game "$wow" && break
        tries=$((tries + 1))
        [ "$tries" -lt 5 ] || die "no game at \"$wow\" as Docker sees it, after five tries"
        say "no game at \"$wow\" as Docker sees it: $(share_hint "$wow"); then answer again" >&2
        found=""
      done
    else
      wow=$found
    fi
  fi
fi
has_game "$wow" \
  || die "no game folder at ${wow:-(none found)} as Docker sees it (it holds _retail_ / _forever_): pass --wow; $(share_hint "$wow")"
export WOW_DIR="$wow"
docker volume create "$vol" >/dev/null
# Kept for the next install, which then asks nothing.
printf '%s' "$wow" | docker run --rm -i -v "$vol:/v" "$tools" sh -c 'mkdir -p /v/install && cat > /v/install/wow'
# The folders each container mounts (a volume's subpath must exist), owned by the user the coach runs as.
# ci/ and watchtower/ too: the builder writes them through the bridge (as that user).
docker run --rm -v "$vol:/v" "$tools" sh -c \
  'mkdir -p /v/coach/players /v/coach/reference /v/refresh /v/watchtower /v/ci /v/ssh_host_keys &&
   chown -R 1000:1000 /v/coach /v/refresh /v/ci /v/watchtower'
# The bridge's SSH host keys: its image makes them only when their folder is missing, and the folder has to
# exist for the mount, so they are made here, once.
if [ -n "$bridge_key" ]; then
  docker run --rm -v "$vol:/v" "$tools" sh -c \
    'ls /v/ssh_host_keys/ssh_host_*_key >/dev/null 2>&1 || {
       apk add -q --no-cache openssh-keygen >/dev/null && mkdir -p /tmp/k/etc/ssh && ssh-keygen -A -f /tmp/k &&
       cp /tmp/k/etc/ssh/ssh_host_* /v/ssh_host_keys/; }'
fi

profiles=""
if [ -n "$bridge_key" ]; then
  profiles="bridge"
  export BRIDGE_PUBLIC_KEY="$bridge_key"
fi
if [ "$ci" = 1 ]; then
  profiles="${profiles:+$profiles,}ci"
  for v in wow-coach_ci-runner wow-coach_ci-cargo wow-coach_ci-rustup; do docker volume create "$v" >/dev/null; done
  tar -C "$HERE" -cf - ci-runner.sh | docker run --rm -i -v "$vol:/v" "$tools" sh -c 'tar -C /v/ci -xf - && chmod 755 /v/ci/ci-runner.sh'
fi
export COMPOSE_PROFILES="$profiles"

say "server: pulling and starting"
# shellcheck disable=SC2086 # the extra -f, when there is one, is two words
docker compose -f "$HERE/server.yaml" $srv_extra up -d --pull always
say "client: pulling and starting"
# shellcheck disable=SC2086
docker compose -f "$HERE/client.yaml" -f "$HERE/profiles.yaml" $cli_extra up -d --pull always

if [ "$addon" = 1 ]; then
  # Only Interface/AddOns/ForeverCoach of each flavor that has the game in it (a flavor never launched has
  # no WTF yet): a /reload in game loads it.
  tar -C "$HERE/addon" -cf - . | docker run --rm -i --mount "type=bind,\"source=$wow\",target=/wow" "$tools" sh -c '
    mkdir -p /tmp/a && tar -C /tmp/a -xf - && n=0
    for d in /wow/_*_; do
      { [ -d "$d/Interface" ] || [ -d "$d/WTF" ]; } || continue
      mkdir -p "$d/Interface/AddOns/ForeverCoach" && cp -R /tmp/a/. "$d/Interface/AddOns/ForeverCoach/" && echo "addon: ${d#/wow/}" && n=$((n+1))
    done
    [ "$n" -gt 0 ] || { echo "no game flavor found in /wow: is --wow right?" >&2; exit 1; }'
fi

# The coach answers, and the client is following the game.
i=0
until docker run --rm --network "$network" "$tools" wget -qO- "$COACH_SERVER/version" 2>/dev/null; do
  i=$((i+1)); [ "$i" -lt 30 ] || die "the coach does not answer at $COACH_SERVER (docker logs coach-server)"
  sleep 2
done
echo
for c in coach-server coach-refresher coach-client watchtower; do
  [ "$(docker inspect -f '{{.State.Running}}' "$c" 2>/dev/null)" = true ] || die "$c is not running (docker logs $c)"
done
say "running: coach-server, coach-refresher, coach-client, watchtower"
say
say "Done. The coach answers at http://localhost:7710 on this computer."
say "In game: /reload, so the add-on loads."
say
if [ "$network" = k3d-control-plane ]; then
  say "The companion: a control plane session on the wow-companion profile (it reaches the coach at $COACH_SERVER)."
else
  say "Now the companion, in Claude Code (https://claude.com/claude-code), from any terminal:"
  say
  say "  mkdir wow-companion"
  say "  cd wow-companion"
  say "  claude plugin marketplace add pgmiranda-rk/wow-companion-releases"
  say "  claude plugin install wow-companion@wow-companion --scope project"
  say "  claude"
  say
  say "Say hello. Allow the coach's tools, and its live watch, when Claude Code asks."
fi
